package com.hsbc.DAO;

import java.util.List;


public interface Interface_methods<T> {


	public List<T> getAll_Items();
	
	public void add(List<T> e );

	
}

