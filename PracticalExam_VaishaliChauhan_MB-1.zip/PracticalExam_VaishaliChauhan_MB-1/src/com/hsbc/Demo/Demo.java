package com.hsbc.Demo;

import com.hsbc.inheritance.Apparel;
import com.hsbc.inheritance.FoodItems;
import com.hsbc.util.Food_items_data;

public class Demo {
	public static void main(String[] args) {
		


	}
}
