package com.DataAccess;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import com.ListLogic.ListNew;

/**
 * This class will provide the access to the database
 * @author mohit
 *
 */

public class DbConnection {
	Connection con;
	public DbConnection() {
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
			 con= DriverManager.getConnection("jdbc:derby://localhost:1527/tp1");
			
			// These comments will create the table in the database
			//Statement stt = con.createStatement();	
			 //stt.execute("Create table listFinal (id int, title varchar(250), description varchar(1000), date varchar(15), status int, PRIMARY KEY (id))");
				
				
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		}
		catch (SQLException ee) {
			
			ee.printStackTrace();
		}
		
	}
	
	/**
	 * This function will insert the new task in the database
	 * @param n is id
	 * @param a is title
	 * @param b is description
	 * @param c is date
	 */
	public void insert(int n, String a, String b, String c) {
		
		try {
			PreparedStatement st = con.prepareStatement("insert into listFinal values(?,?,?,?,?)");
			st.setInt(1,n);
			st.setString(2, a);
			st.setString(3, b);
			st.setString(4, c);
			st.setInt(5,0);
			st.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
	}
	

	/**
	 * This function retrieves the data from the table
	 * @return arraylist with all the incomplete tasks
	 */
	public ArrayList<ListNew> retrieve() {
		ArrayList<ListNew> al = new ArrayList<>();
		
		
		try {
			PreparedStatement st = con.prepareStatement("Select * from listFinal where status=0 ");
			ResultSet r = st.executeQuery();
			while(r.next()) {
				ListNew l = new ListNew(r.getInt("id"),r.getString("title"), r.getString("description"), r.getString("date") );
				//System.out.println(r.getInt("id")+" "+r.getString("title")+" "+r.getString("description")+" "+r.getString("date"));
				al.add(l);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return al;
		
		
	}
	
	/**
	 * This function retrieves the data of all completed tasks from the table
	 * @return arraylist with all the complete tasks
	 * 
	 */
	public ArrayList<ListNew> retrieveComplete() {
		ArrayList<ListNew> al = new ArrayList<>();
		
		
		try {
			PreparedStatement st = con.prepareStatement("Select * from listFinal where status=1");
			ResultSet r = st.executeQuery();
			while(r.next()) {
				ListNew l = new ListNew(r.getInt("id"),r.getString("title"), r.getString("description"), r.getString("date") );
				//System.out.println(r.getInt("id")+" "+r.getString("title")+" "+r.getString("description")+" "+r.getString("date"));
				al.add(l);
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		
		return al;
		
		
	}
	
	
	/**
	 * This function retrieves all the tasks from the table
	 * @return an arraylist which has all the tasks
	 */
	public ArrayList<ListNew> retrieveAll() {
		ArrayList<ListNew> al = new ArrayList<>();
		
		
		try {
			PreparedStatement st = con.prepareStatement("Select * from listFinal");
			ResultSet r = st.executeQuery();
			while(r.next()) {
				ListNew l = new ListNew(r.getInt("id"),r.getString("title"), r.getString("description"), r.getString("date") );
				//System.out.println(r.getInt("id")+" "+r.getString("title")+" "+r.getString("description")+" "+r.getString("date"));
				al.add(l);
			}
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return al;
		
		
	}
	
	
	/**
	 * This function closes the connection with the database after the processing is done
	 */
	public void close() {
		try {
			con.close();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
	}
	
	
	/**
	 * This function will clear the table data
	 */
	public void truncate() {
		Statement stt;
		try {
			stt = con.createStatement();
			stt.execute("Truncate Table listFinal");
		} catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
	}
	
	/**
	 * This function will update the tasks after edit function
	 * @param id is task id
	 * @param a is the task title
	 * @param b is the task description
	 * @param c is the edit task date
	 */
	public void update(int id, String a, String b, String c) {
		
		PreparedStatement st;
		try {
			st = con.prepareStatement("update listFinal set title=?,description=?, date=? where id=? ");
			st.setInt(4,id);
			st.setString(1, a);
			st.setString(2, b);
			st.setString(3, c);
			st.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}		
		
	}
	
	
	/**
	 * This function modifies the status of the task 
	 * @param id
	 * @param status
	 */
	public void updateStatus(int id, int status) {
		
		PreparedStatement st;
		try {
			st = con.prepareStatement("update listFinal set status=? where id=? ");
			st.setInt(1,status);
			st.setInt(2, id);
			
			st.executeUpdate();
		} catch (SQLException e) {
		
			e.printStackTrace();
		}		
		
	}
	
	/**
	 * This function will delete the task from the database
	 * @param id is the id of task to be deleted
	 */
	public void delete(int id) {
		
		PreparedStatement st;
		try {
			st = con.prepareStatement("Delete from listFinal where id=? ");
			st.setInt(1,id);
			
			st.executeUpdate();
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
		
	}
	

	
}

