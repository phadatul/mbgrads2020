package com.ListLogic;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DataAccess.DbConnection;

/**
 * Servlet implementation class EditListServ which will edit a already existing ToDo list to the database
 */
@WebServlet("/EditListServ")
public class EditListServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EditListServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//Fetching the title and description from the front end
		String title=request.getParameter("title");
		String description=request.getParameter("description");
		int id = Integer.parseInt(request.getParameter("id"));
		
		PrintWriter out = response.getWriter();
		
		//Fetching the system date of editing a new list
		long millis=System.currentTimeMillis();  
		java.sql.Date datee=new java.sql.Date(millis);
		String date = datee.toString();
	
		//Connection to the database
		DbConnection connection3 = new DbConnection();
		
		//update query execution
		connection3.update(id, title, description, date);;
		

		//after the edit to the data, this is redirected to the home page where all lists are displayed
		response.sendRedirect("AddListDataServ");
	}

}
