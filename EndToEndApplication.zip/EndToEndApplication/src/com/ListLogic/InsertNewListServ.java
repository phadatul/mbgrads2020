package com.ListLogic;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DataAccess.DbConnection;

/**
 * Servlet implementation class InsertNewListServ which will insert a new ToDo list to the database
 * 
 * @author mohit
 */
@WebServlet("/InsertNewListServ")
public class InsertNewListServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertNewListServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//Fetching the title and description from the front end
		String title=request.getParameter("title");
		String description=request.getParameter("description");
		PrintWriter out = response.getWriter();
		
		//Fetching the system date of adding a new list
		long millis=System.currentTimeMillis();  
		java.sql.Date datee=new java.sql.Date(millis);
		String date = datee.toString();
	
		//Connection to the database
		DbConnection connection2 = new DbConnection();
		int idd = connection2.retrieveAll().size();
		int id=idd+1;
		System.out.println(id);
		
		//insert query execution
		connection2.insert(id,title,description,date);
		
		//after the addition to the data, this is redirected to the home page where all lists are displayed
		response.sendRedirect("AddListDataServ");
		//connection2.close();
	}

}
