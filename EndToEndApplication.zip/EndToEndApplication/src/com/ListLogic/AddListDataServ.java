package com.ListLogic;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DataAccess.DbConnection;


/**
 * Servlet implementation class AddListDataServ
 * This is the home page where all the existing tasks are mentioned
 */
@WebServlet("/AddListDataServ")
public class AddListDataServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddListDataServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String title=request.getParameter("title");
		String description=request.getParameter("description");
		PrintWriter out = response.getWriter();
		long millis=System.currentTimeMillis();  
		java.sql.Date datee=new java.sql.Date(millis);
		String date = datee.toString();
	
		//Connection to the databse is established
		DbConnection connection1 = new DbConnection();
		//connection.insert(ii,"Third","Third description", date);
		
		//All the tasks are fetched from the database in the arraylist
		ArrayList<ListNew> al = new ArrayList<>();
		al = connection1.retrieve();		
		
		//Arraylist is sent to the frontend where all the tasks are shown
		RequestDispatcher rd = request.getRequestDispatcher("MyToDoList.jsp");
		request.setAttribute("Ans", al );
		rd.forward(request, response);
		//connection1.close();
	}

}
