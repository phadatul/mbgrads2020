package com.ListLogic;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DataAccess.DbConnection;

/**
 * Servlet implementation class ShoeCompleteTaskServ 
 * This servlet will display the Completed Tasks List on the Completed Task List page
 */
@WebServlet("/ShowCompleteTaskServ")
public class ShowCompleteTaskServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowCompleteTaskServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		//Connection to the database
		DbConnection connection5 = new DbConnection();
		//connection.insert(ii,"Third","Third description", date);
		
		//Fetched all the completed tasks in a arraylsit
		ArrayList<ListNew> al = new ArrayList<>();
		al = connection5.retrieveComplete();		
		
		//Send the arraylist to the jsp page where it can be read and displayed on front end
		RequestDispatcher rd = request.getRequestDispatcher("CompleTasKList.jsp");
		request.setAttribute("ans", al );
		rd.forward(request, response);
		
		
	}

}
