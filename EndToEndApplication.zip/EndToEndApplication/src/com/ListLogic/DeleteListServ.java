package com.ListLogic;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.DataAccess.DbConnection;

/**
 * Servlet implementation class DeleteListServ
 * This servlet provides the delete functionality to the application to delete any task.
 */
@WebServlet("/DeleteListServ")
public class DeleteListServ extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public DeleteListServ() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//id of the task to be deleted is fetched from the front end.
		int id = Integer.parseInt(request.getParameter("id"));
		
		//connection to the database is established.
		DbConnection connection3 = new DbConnection();
		
		//Delet query execution
		connection3.delete(id);
		
		//after deletion, the page is redirected to the home page where all lists are shown
		response.sendRedirect("AddListDataServ");
		
	}

}
