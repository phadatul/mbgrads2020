package com.hsbc.storage;

import java.util.List;

public class Printingofdata {
	public  static void printRecords(List l) {
		System.out.println(l);
	}

}
