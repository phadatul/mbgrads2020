package com.hsbc.view;

import java.util.ArrayList;
import java.util.List;

import com.hsbc.dao.Categories;
import com.hsbc.entity.Apparel;
import com.hsbc.entity.Electronics;
import com.hsbc.entity.FoodItems;
import com.hsbc.utility.GetRequiredData;

public class Main {
/**
 * main class to give the  final output
 * @param args
 */
	
	
	
	
	public static void main(String[] args) {
		
		List<FoodItems> foodItems3=new ArrayList<FoodItems>();
		List<Apparel> apparels=new ArrayList<Apparel>();
		List<Electronics> e=new ArrayList<Electronics>();
		
		FoodItems  foodItems=new FoodItems(101, "Milk", 20, "11 Sept, 2020", "12 Sept ,2020", 40,true);
		FoodItems  foodItems1=new FoodItems(102, "Curd ", 15, "11 Sept, 2020", "12 Sept ,2020", 20,true);
		FoodItems  foodItems2=new FoodItems(103, "Cake", 200, "11 Sept, 2020", "12 Sept ,2020", 12,false);
		
		Apparel apparel=new Apparel(201, "T-Shirt", 200, "Large", "Cotton", 50);
		Apparel apparel1=new Apparel(202, "Shiry", 500, "Medium", "Cotton", 32);
		Apparel apparel2=new Apparel(203, "T-Shirt", 200, "Medium", "Cotton", 20);
		
		Electronics  electronics=new Electronics(301, "Washing Machine", 15000, 12,100);
		Electronics  electronics1=new Electronics(302, "TV", 20000, 21,97);
		Electronics  electronics2=new Electronics(303, "Mobile", 40000, 24,54);
		
		
		foodItems3.add(foodItems);
		foodItems3.add(foodItems1);
		foodItems3.add(foodItems2);
		
		apparels.add(apparel);
		apparels.add(apparel1);
		apparels.add(apparel2);
		
		e.add(electronics);
		e.add(electronics1);
		e.add(electronics2);
		
		Categories<FoodItems> categories=new Categories<FoodItems>();
		categories.addCategory("Food Items", foodItems3);
		
		Categories<Apparel> categories2=new Categories<Apparel>();
		categories2.addCategory("Apparel", apparels);
		
		Categories<Electronics> categories3=new  Categories<Electronics>();
		categories3.addCategory("Electronics", e);
		
		
		GetRequiredData<FoodItems> data=new GetRequiredData<>();
		System.out.println(data.getTopThreeItems("FoodItems"));
		
		GetRequiredData<FoodItems> data1=new GetRequiredData<>();
		System.out.println(data.getTopThreeItems("Apparel"));
		
		GetRequiredData<FoodItems> data2=new GetRequiredData<>();
		System.out.println(data.getTopThreeItems("Electronics"));
		
		
		
		
	}
	
	
}
