package com.hsbc.entity;

import java.util.ArrayList;
import java.util.List;

import com.hsbc.dao.Categories;

public class Electronics extends Categories<Electronics>{

	
	List<Electronics> list=new ArrayList<Electronics>();
	private int code;
	private String name;
	private double price;
	private int warranty;
	private int quantity;
	
	public Electronics() {
		// TODO Auto-generated constructor stub
	}


	public Electronics(int code, String name, double price, int warranty, int quantity) {
		super();
		this.code = code;
		this.name = name;
		this.price = price;
		this.warranty = warranty;
		this.quantity = quantity;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + code;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + quantity;
		result = prime * result + warranty;
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Electronics other = (Electronics) obj;
		if (code != other.code)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (quantity != other.quantity)
			return false;
		if (warranty != other.warranty)
			return false;
		return true;
	}


	public int getCode() {
		return code;
	}


	public void setCode(int code) {
		this.code = code;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public double getPrice() {
		return price;
	}


	public void setPrice(double price) {
		this.price = price;
	}


	public int getWarranty() {
		return warranty;
	}


	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	@Override
	public void addCategory(String s, List<Electronics> list) {
		// TODO Auto-generated method stub
		super.addCategory(s, list);
	}
	
	@Override
	public List<Electronics> getCategory(String s) {
		// TODO Auto-generated method stub
		return super.getCategory(s);
	}
	
}
