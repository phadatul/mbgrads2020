package com.hsbc.entity;

import java.util.ArrayList;
import java.util.List;

import com.hsbc.dao.Categories;

public class FoodItems extends Categories<FoodItems>  implements Comparable<FoodItems> {
	
	
	List<FoodItems> list=new ArrayList<FoodItems>();
	private int code;
	private String name;
	private  double price;
	private String date_manufacture;
	private String date_expiry;
	private int quantity;
	private boolean vegetarian;
	
	public FoodItems() {
		// TODO Auto-generated constructor stub
	}

	public FoodItems(int code, String name, double price, String date_manufacture, String date_expiry, int quantity,
			boolean vegetarian) {
		super();
		this.code = code;
		this.name = name;
		this.price = price;
		this.date_manufacture = date_manufacture;
		this.date_expiry = date_expiry;
		this.quantity = quantity;
		this.vegetarian = vegetarian;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getDate_manufacture() {
		return date_manufacture;
	}

	public void setDate_manufacture(String date_manufacture) {
		this.date_manufacture = date_manufacture;
	}

	public String getDate_expiry() {
		return date_expiry;
	}

	public void setDate_expiry(String date_expiry) {
		this.date_expiry = date_expiry;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public boolean isVegetarian() {
		return vegetarian;
	}

	public void setVegetarian(boolean vegetarian) {
		this.vegetarian = vegetarian;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + code;
		result = prime * result + ((date_expiry == null) ? 0 : date_expiry.hashCode());
		result = prime * result + ((date_manufacture == null) ? 0 : date_manufacture.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + quantity;
		result = prime * result + (vegetarian ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		FoodItems other = (FoodItems) obj;
		if (code != other.code)
			return false;
		if (date_expiry == null) {
			if (other.date_expiry != null)
				return false;
		} else if (!date_expiry.equals(other.date_expiry))
			return false;
		if (date_manufacture == null) {
			if (other.date_manufacture != null)
				return false;
		} else if (!date_manufacture.equals(other.date_manufacture))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		if (Double.doubleToLongBits(price) != Double.doubleToLongBits(other.price))
			return false;
		if (quantity != other.quantity)
			return false;
		if (vegetarian != other.vegetarian)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "FoodItems [code=" + code + ", name=" + name + ", quantity=" + quantity + ", vegetarian=" + vegetarian
				+ "]";
	}

	@Override
	public void addCategory(String s, List<FoodItems> list) {
		// TODO Auto-generated method stub
		super.addCategory(s, this.list);
	}
	
	@Override
	public List<FoodItems> getCategory(String s) {
		// TODO Auto-generated method stub
		
		return super.getCategory(s);
	}
	
	@Override
	public int compareTo(FoodItems o) {
		// TODO Auto-generated method stub
		if (this.quantity > o.quantity) 
			  return 1;
		  else if(this.quantity<o.quantity)
			  return -1;
		  else return 0; 
	
	}
	
	

}
