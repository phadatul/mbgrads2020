package com.hsbc.exceptions;

public class ItemCodeAlreadyExistsException extends Exception {
	
	

}
