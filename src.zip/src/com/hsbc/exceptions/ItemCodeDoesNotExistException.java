package com.hsbc.exceptions;

public class ItemCodeDoesNotExistException extends Exception{

	
	
}
