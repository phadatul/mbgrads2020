package com.hsbc.dao;

import java.util.HashMap;
import java.util.List;

import com.hsbc.exceptions.ItemCodeAlreadyExistsException;

/**
 * This class extends interface category and implements its method. The categories hashmap wil store the Products 
 * array list in the formof key value pair.
 * @author SANTVANA NIGAM
 *
 * @param <T>
 */
public class Categories<T> implements Category<T>{

	HashMap<String,List<T>> map=new HashMap<String,List<T>>();
	
	
	public void addCategory(String s,List<T> list)
	{
		map.put(s,list);
	}
	
	public List<T> getCategory(String s){
		
		return map.get(s);
			
	}
	
	
}
