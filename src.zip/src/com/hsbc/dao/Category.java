package com.hsbc.dao;

import java.util.List;

/**
 * Interface conists of addCategory and GetCategory Methods
 * @author SANTVANA NIGAM
 *
 * @param <T>
 */
public interface Category<T> {

	public void addCategory(String s,List<T> list);
	
	public List<T> getCategory(String s) ;
	
}
