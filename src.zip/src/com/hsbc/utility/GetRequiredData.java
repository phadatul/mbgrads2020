package com.hsbc.utility;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.hsbc.dao.Categories;
import com.hsbc.entity.Apparel;
import com.hsbc.entity.Electronics;
import com.hsbc.entity.FoodItems;
/**
 * this class is returns the top three items according to quantity
 * @author SANTVANA NIGAM
 *
 * @param <T>
 */

public class GetRequiredData<T> extends Categories<T> {
	
	
	
	public GetRequiredData() {
		// TODO Auto-generated constructor stub
	}
	
	public List<T> getTopThreeItems(String s)
	{
		
		List<T> list=new ArrayList<T>();
		list=getCategory(s);
        Collections.sort((List<T>) list);
        List<T> list1=new ArrayList<T>();
        
        
		return list1;
		
	}
	
	
	
	

}
