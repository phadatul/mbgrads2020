package com.hsbc.mvc.model;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.hsbc.mvc.model.Users;


public class Utility {
	
	public static int checkIfExists(Users user) {
		DBConnection db = new DBConnection();
		Statement st = db.getStatement();
		ResultSet rs;
		int flag = 1;
			try {
				rs = st.executeQuery("select * from users where email="+user.getEmail()+"and password ="+user.getPassword());
				if (rs==null)
					flag = 0;
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		if (flag==0)
			return 0;
		else 
			return 1;		
		
		
	}
	
	public static List fetchList(Users user) {
		DBConnection db = new DBConnection();
		Statement st = db.getStatement();
		ResultSet rs;
		List l = new ArrayList();
		int flag = 1;
			try {
				rs = st.executeQuery("select priority,description,dateofcompletion from ToDoList where email='"+user.getEmail()+"'");
				while(rs.next())
				{
					System.out.println(rs);
					l.add(rs.getInt(1)+" "+ rs.getString(2)+ " "+ rs.getDate(3));
					
				}
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		return l;
		
		
	}
	
	

}
