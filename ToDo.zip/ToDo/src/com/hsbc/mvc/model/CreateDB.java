package com.hsbc.mvc.model;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateDB {
	public static void main(String[] args) {
		try {
			
				Class.forName("org.apache.derby.jdbc.ClientDriver");

				Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/ToDoList;create=true");

				Statement st = con.createStatement();
				
				//st.execute("drop table users");
				//st.execute("drop table todolist");
//				st.execute("create table users(email varchar(20), password varchar(10))");
//				st.execute("create table ToDoList(email varchar(20), priority integer, description varchar(50), dateOfCompletion date)");

				st.execute("insert into users values('neha@gmail.com', '123456')");
				st.execute("insert into users values('ish@gmail.com', 'qwerty')");
				st.execute("insert into todolist values('neha@gmail.com', 4, 'Complete this.', '12/10/2020')");
				st.execute("insert into todolist values('neha@gmail.com', 3, 'Complete this.', '12/10/2020')");
				st.execute("insert into todolist values('neha@gmail.com', 2, 'Complete this.', '12/10/2020')");
				st.execute("insert into todolist values('ish@gmail.com', 1, 'Complete this.', '12/10/2020')");
				con.close();

			} catch (ClassNotFoundException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}

	}

}
