package com.hsbc.mvc.model;

import java.sql.Date;

public class ToDoList {
	
	public String email;
	public Integer priority;
	public String description;
	public Date date;
	public Integer getPriority() {
		return priority;
	}
	
	public ToDoList(Integer priority, String description, Date date) {
		super();
		this.priority = priority;
		description = description;
		this.date = date;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		description = description;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "ToDoList [priority=" + priority + ", Description=" + description + ", date=" + date + "]";
	}
	
	

}
