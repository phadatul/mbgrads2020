package com.phonebook.dao;

import java.util.Map;

import com.phonebook.model.Contact;

public class Demo {
	
	public static void main(String[] args) {
		
		ContactDAOImp obj=new ContactDAOImp();
		obj.addContact("Susan", "7339936039", "Pune");
		Map<Integer, Contact> m=obj.getAllContacts();
		obj.addContact("Sukriti", "9236190401", "Delhi");
		System.out.println(m);
	}

}
