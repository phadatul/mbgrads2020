package com.phonebook.dao;

import java.util.Map;

import com.phonebook.model.Contact;

public interface ContactDAO {
	
	public void addContact(String name, String address, String phoneno);
	public Map<Integer, Contact> getContactById(String id);
	public Map<Integer, Contact> getAllContacts();
	public void updateContact(String id, String name, String address, String phoneno);
	public void deleteContact(String id) ;
	
	
}
