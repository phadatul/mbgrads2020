package com.hsbc.exceptions;

public class InvalidCategoryException extends Exception {
	
	public InvalidCategoryException() {
		
		System.out.println("Invalid Product Category");
	}

}
