package com.hsbc.exceptions;

public class ItemCodeAlreadyPresentException extends Exception{
	
	public ItemCodeAlreadyPresentException() {
		System.out.println("Item Code Already Present");
	}
	
	

}
