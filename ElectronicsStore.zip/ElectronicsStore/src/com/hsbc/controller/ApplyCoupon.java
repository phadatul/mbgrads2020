package com.hsbc.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hsbc.dao.ElectronicItemsAdminImpl;
import com.hsbc.dao.ElectronicsItemsUserImpl;
import com.hsbc.model.Laptops;
import com.hsbc.model.Mobiles;
import com.hsbc.model.Television;
import com.hsbc.model.Watches;

/**
 * This servlet will update the price in the cart table after applying the respective dicount on the item and redirect to cart.jsp so that the changes  
 * are reflected over there. 
 * 
 * Note:  The price in the cart table is getting updated and not in the item tables(laptops,mobiles,watches  and television)
 * 
 * @author SANTVANA NIGAM
 *
 */
@WebServlet("/ApplyCoupon")
public class ApplyCoupon extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public ApplyCoupon() {
        super();
       
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String type = request.getParameter("type");
		String id = request.getParameter("id");
		String referer = request.getHeader("Referer");
		
		ElectronicItemsAdminImpl<Watches> watches = new ElectronicItemsAdminImpl<>();
		ElectronicItemsAdminImpl<Mobiles> mobiles = new ElectronicItemsAdminImpl<>();
		ElectronicItemsAdminImpl<Laptops> laptops = new ElectronicItemsAdminImpl<>();
		ElectronicItemsAdminImpl<Television> television = new ElectronicItemsAdminImpl<>();
		
		ElectronicsItemsUserImpl cart = new ElectronicsItemsUserImpl();
		int i=Integer.parseInt(id);
		double discountedprice;
		if(i>=100 && i<=199)
		{
			Laptops e=new Laptops();
			e=laptops.getItem(i, type);
			discountedprice=e.getItemCostAfterDiscount();
			cart.updateItemPrice(i,discountedprice);
		}
		else if(i>=200 && i<=299)
		{
			Mobiles e=new Mobiles();
			e=mobiles.getItem(i, type);
			discountedprice=e.getItemCostAfterDiscount();
			cart.updateItemPrice(i,discountedprice);
		}
		else if(i>=300 && i<=399)
		{
			Watches e=new Watches();
			e=watches.getItem(i, type);
			discountedprice=e.getItemCostAfterDiscount();
			cart.updateItemPrice(i,discountedprice);
		}
		else
		{
			Television e=new Television();
			e=television.getItem(i, type);
			discountedprice=e.getItemCostAfterDiscount();
			cart.updateItemPrice(i,discountedprice);
		}
		response.sendRedirect(referer);
		
		
	}

}
