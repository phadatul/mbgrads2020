package com.hsbc.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hsbc.dao.ElectronicItemsAdminImpl;
import com.hsbc.dao.ElectronicsItemsUserImpl;
import com.hsbc.model.Laptops;
import com.hsbc.model.Mobiles;
import com.hsbc.model.Television;
import com.hsbc.model.Watches;


/**
 * This servlet will check which item is being requested to be added to the cart and will add that item to the cart table.
 * @author SANTVANA NIGAM
 *
 */

@WebServlet("/AddToCart")
public class AddToCart extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public AddToCart() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		this.doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		//PrintWriter out = response.getWriter();
		
		String type = request.getParameter("type");
		String id = request.getParameter("id");
		
		ElectronicsItemsUserImpl cart = new ElectronicsItemsUserImpl();
		
		String referer = request.getHeader("Referer");
		
		// out.println(referer);
		
		if (type.equals("laptops"))
		{
			ElectronicItemsAdminImpl<Laptops> laptops = new ElectronicItemsAdminImpl<>();
			Laptops l = new Laptops();
			int i = Integer.parseInt(id);

			l = laptops.getItem(i, type);

			cart.addToCart(l.getId(), l.getPrice());
		} else if (type.equals("mobiles")) {
			ElectronicItemsAdminImpl<Mobiles> mobiles = new ElectronicItemsAdminImpl<>();
			Mobiles m = new Mobiles();
			m = mobiles.getItem(Integer.parseInt(id), type);

			cart.addToCart(m.getId(), m.getPrice());
		} else if (type.equals("television")) {
			
			ElectronicItemsAdminImpl<Television> tele = new ElectronicItemsAdminImpl<>();
			Television t = new Television();
			t = tele.getItem(Integer.parseInt(id), type);
			// System.out.println("We are in television");
			cart.addToCart(t.getId(), t.getPrice());
			
		} else {
			ElectronicItemsAdminImpl<Watches> watches = new ElectronicItemsAdminImpl<>();
			Watches w = new Watches();
			int i = Integer.parseInt(id);
			w = watches.getItem(i, type);

			System.out.println("We are in watches");
			cart.addToCart(w.getId(), w.getPrice());
		}
		response.sendRedirect(referer);
	}

}
