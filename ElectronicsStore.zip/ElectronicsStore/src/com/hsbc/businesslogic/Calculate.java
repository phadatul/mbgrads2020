package com.hsbc.businesslogic;

import java.util.Iterator;
import java.util.List;
import java.util.Map;


/**
 * This class will  return the total amount(after  discount) and the actual amount of the currently present items in the  cart. 
 * @author SANTVANA NIGAM
 *
 */
public class Calculate {
	
	
	public Calculate() {
		// TODO Auto-generated constructor stub
	}
	
	
	public double totalAmount(Map<Integer, Double> map)
	{
		double total=0.0;
		Iterator<Double> itr=map.values().iterator();
		while(itr.hasNext())
		{
			total=total+itr.next();
		}
		return total;
	}
	
	
	public double actualAmount(List<Double> list)
	{
		double total=0.0;
		Iterator<Double> itr=list.iterator();
		while(itr.hasNext())
		{
			total=total+itr.next();
		}
		return total;
	}

}
