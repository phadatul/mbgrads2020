package com.hsbc.connectivity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * This is a connection class  to establish connection with the database and to get Statement and PreparedStatement objects.
 * @author SANTVANA NIGAM
 *
 */

public class DBConnection {


	Connection connection;
	Statement statement;
	PreparedStatement preparedStatement;
	
	
	public DBConnection() {
		
		try {
			Class.forName("org.apache.derby.jdbc.ClientDriver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("EROORRRR");
		}
		
	}
	
	public Statement getStatement()
	{
		try {
			connection=DriverManager.getConnection("jdbc:derby://localhost:1527/ecom;create=true");
			statement=connection.createStatement();
			return statement;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public PreparedStatement getPreparedStatement(String sql)
	{
		try {
			connection=DriverManager.getConnection("jdbc:derby://localhost:1527/ecom;create=true");
			preparedStatement=connection.prepareStatement(sql);
			return preparedStatement;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

	
	
}
