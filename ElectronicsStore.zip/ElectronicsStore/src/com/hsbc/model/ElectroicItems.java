package com.hsbc.model;

/**  
 * this interface provides a function to get the item cost after discount. It is implemented by
 * Laptops,Mobiles ,Watches and Television classes.
 * @author SANTVANA NIGAM
 *
 */
public interface ElectroicItems {
	
	
	
	public double getItemCostAfterDiscount();
	

}
