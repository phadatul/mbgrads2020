package com.hsbc.dao;

import java.util.List;
/**
 * This is a generic interface that provides functions to perform CRUD operations on the tables of  the subclasses of ElectronicItems
 * @author SANTVANA NIGAM
 *
 * @param <T>
 */
public interface ElectronicItemsAdmin<T>
{
	
	public List<T> getAllItems(String s);
	
	public void createItemTable(String s);
	
	public void insertItem(T t);
	
	public void updateItemDiscount(T t,double discount);
	
	public void  deleteItem(T t);
	
	public T getItem(int id,String s);
	
	public void clearAll(String s);
	
	

}
