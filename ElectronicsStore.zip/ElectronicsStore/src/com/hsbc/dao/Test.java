package com.hsbc.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;



/*
 * This is a sample class to test the functionality of  ElectronicItemsUserImpl class
 */
public class Test {

	
	
	public static void main(String[] args) {
		
		ElectronicsItemsUserImpl cart=new ElectronicsItemsUserImpl();
		//cart.createCartTable();
		//cart.clearCartTable();
		Map<Integer, Double> map=new TreeMap<Integer, Double>();
		map=cart.getAllItems();
		System.out.println(map);
	}
}
