package com.hsbc.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.hsbc.connectivity.DBConnection;
/**
 * This class implements ElectronicItemsUser interface
 * @author SANTVANA NIGAM
 *
 */

public class ElectronicsItemsUserImpl implements ElectronicsItemsUser {

	Statement statement;
	PreparedStatement preparedStatement;
	DBConnection connection;

	public ElectronicsItemsUserImpl() {
		connection = new DBConnection();
	}

	@Override
	public void createCartTable() {
		try {
			String sql = "create table cart(id integer,price double)";
			this.preparedStatement = this.connection.getPreparedStatement(sql);
			this.preparedStatement.execute();
			System.out.println("Table  successfully created");

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

		}

	}

	@Override
	public boolean clearCartTable() {
		try {
			String sql = "delete from cart";
			this.preparedStatement = this.connection.getPreparedStatement(sql);
			this.preparedStatement.execute();
			return true;

		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			return false;
		}

	}

	@Override
	public void deleteCartItem(int id) {

		try {

			this.preparedStatement = this.connection.getPreparedStatement("delete from cart where id=?");

			this.preparedStatement.setInt(1, id);

			this.preparedStatement.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

	}

	@Override
	public void addToCart(int id,double price) {
		
		
		try
		{
			this.preparedStatement = this.connection.getPreparedStatement("insert into cart values(?,?)");
			this.preparedStatement.setInt(1,id);
			this.preparedStatement.setDouble(2, price);
			this.preparedStatement.executeUpdate();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}

	@Override
	public void updateItemPrice(int id,double price) {
		try {

			this.preparedStatement = this.connection.getPreparedStatement("update cart set price=? where id=?");
			this.preparedStatement.setDouble(1, price);
			this.preparedStatement.setInt(2, id);
			this.preparedStatement.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch blocT
			e1.printStackTrace();
		}
		

	}

	@Override
	public Map<Integer, Double> getAllItems() {
		
		
		Map<Integer, Double> map=new TreeMap<Integer, Double>();
		 try {
            
			this.preparedStatement = this.connection.getPreparedStatement("select * from cart");
			
			ResultSet rs=this.preparedStatement.executeQuery();
			while(rs.next())
			{
				map.put(rs.getInt(1),rs.getDouble(2));
			}
		
		} catch (SQLException e1) {
			// TODO Auto-generated catch blocT
			e1.printStackTrace();
		}
		return map;
	}

}
