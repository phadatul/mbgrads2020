package com.hsbc.dao;

import java.util.ArrayList;
import java.util.List;

import com.hsbc.model.Laptops;
import com.hsbc.model.Mobiles;
import com.hsbc.model.Television;
import com.hsbc.model.Watches;

/**
 * This is an extra class for adding items to the tables: laptops,mobiles,watches and television
 * @author SANTVANA NIGAM
 *
 */
public class StoreData {
	
	public static void main(String[] args) {
		
		ElectronicItemsAdminImpl<Watches> watches=new ElectronicItemsAdminImpl<>();
		ElectronicItemsAdminImpl<Mobiles> mobiles=new ElectronicItemsAdminImpl<>();
		ElectronicItemsAdminImpl<Laptops> laptops=new ElectronicItemsAdminImpl<>();
		ElectronicItemsAdminImpl<Television> television=new ElectronicItemsAdminImpl<>();
		
		//watches.createItemTable("watches");
		//mobiles.createItemTable("mobiles");
		//laptops.createItemTable("laptops");
		//television.createItemTable("television");
		
		/*
		 * Laptops laptops2=new Laptops(101, "Acer Nitro 5", "laptop101.jpg", 65000,
		 * 15); laptops.insertItem(laptops2);
		 */
		/*
		 * laptops.clearAll("laptops"); List<Laptops> la=new ArrayList<Laptops>();
		 * la=laptops.getAllItems("laptops"); System.out.println(la);
		 */
		
		/*
		 * Laptops laptops1=new Laptops(101, "Acer Nitro 5", "laptop101.jpg", 65000,15);
		 * Laptops laptops2=new Laptops(102, "Asus Zenboook Duo", "laptop102.jpg",
		 * 50000,12); Laptops laptops3=new Laptops(103, "Dell Inspiron 157501",
		 * "laptop103.jpg", 47000,6); Laptops laptops4=new Laptops(104,
		 * "Lenovo Thinkpad E14", "laptop104.jpg", 125000,20); Laptops laptops5=new
		 * Laptops(105, "Lenovo Yoga S740", "laptop105.jpg", 80000,16);
		 * 
		 * Television tele1=new Television(401, "JVC 108cm HD Display", "tele401.jpeg",
		 * 60000, 6); Television tele2=new Television(402, "Philips 108cm HD Display",
		 * "tele402.jpeg", 34000, 6); Television tele3=new Television(403,
		 * "Sharp 101.6 HD Display", "tele403.jpg", 36000, 6); Television tele4=new
		 * Television(404, "Toshiba 103cm HD Display", "tele404.jpg", 45000, 6);
		 * Television tele5=new Television(405, "Sharp 61 HD Display", "tele405.jpg",
		 * 125000, 6);
		 * 
		 * Mobiles mobiles1=new Mobiles(201, "Samsung A31", "mobile201.jpg", 20000, 4);
		 * Mobiles mobiles2=new Mobiles(202, "Samsung M31", "mobile202.jpg", 20000, 3);
		 * Mobiles mobiles3=new Mobiles(203, "Nokia 5.3 Android 1", "mobile203.jpg",
		 * 13000, 2); Mobiles mobiles4=new Mobiles(204, "Oppo A52020", "mobile204.jpg",
		 * 17000, 1); Mobiles mobiles5=new Mobiles(205, "MI Redmi 9A", "mobile205.jpg",
		 * 8000, 0);
		 * 
		 * Watches watches1=new Watches(301, "Laurels 009S", "watch301.jpg", 18000, 5);
		 * Watches watches2=new Watches(302, "Megalith 008M", "watch302.jpg", 5000, 10);
		 * Watches watches3=new Watches(303, "Redux RWS0200S", "watch303.jpg", 4000, 0);
		 * Watches watches4=new Watches(304, "Titan M50090", "watch304.jpg", 10000, 7);
		 * Watches watches5=new Watches(305, "Titan NH1580YL05", "watch305.jpeg", 25000,
		 * 3);
		 * 
		 * laptops.insertItem(laptops1); laptops.insertItem(laptops2);
		 * laptops.insertItem(laptops3); laptops.insertItem(laptops4);
		 * laptops.insertItem(laptops5);
		 * 
		 * television.insertItem(tele1); television.insertItem(tele2);
		 * television.insertItem(tele3); television.insertItem(tele4);
		 * television.insertItem(tele5);
		 * 
		 * mobiles.insertItem(mobiles1); mobiles.insertItem(mobiles2);
		 * mobiles.insertItem(mobiles3); mobiles.insertItem(mobiles4);
		 * mobiles.insertItem(mobiles5);
		 * 
		 * watches.insertItem(watches1); watches.insertItem(watches1);
		 * watches.insertItem(watches1); watches.insertItem(watches1);
		 * watches.insertItem(watches1);
		 */
		
		 
	    System.out.println(laptops.getAllItems("laptops"));
	    
	    System.out.println(mobiles.getAllItems("mobiles"));
	    
	    System.out.println(watches.getAllItems("watches"));
	    
	    System.out.println(television.getAllItems("television"));
	    
	}
	}


