package com.hsbc.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.hsbc.connectivity.DBConnection;
import com.hsbc.model.Laptops;
import com.hsbc.model.Mobiles;
import com.hsbc.model.Television;
import com.hsbc.model.Watches;

/**
 * This class implements the ELectronicItemsAdmin interface 
 * @author SANTVANA NIGAM
 *
 * @param <T>
 */

public class ElectronicItemsAdminImpl<T> implements ElectronicItemsAdmin<T>{

	
	Statement statement;
	PreparedStatement preparedStatement;
	DBConnection connection;
	
	public ElectronicItemsAdminImpl() {
		// TODO Auto-generated constructor stub
		
		connection = new DBConnection();
	}
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<T> getAllItems(String s) {
		
		
		List<Object> product=new ArrayList<Object>();
		ResultSet  resultSet=null;
		try {
			this.preparedStatement=this.connection.getPreparedStatement("select * from "+s);
			resultSet=this.preparedStatement.executeQuery();
			if(s.equals("television"))
			{
		    while(resultSet.next())
		    {
		    	product.add(new Television(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getDouble(4), resultSet.getDouble(5)));
		    }
		      return (List<T>)product;
			}
			
			else if(s.equals("mobiles"))
			{
				while(resultSet.next())
			    {
			    	product.add(new Mobiles(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getDouble(4), resultSet.getDouble(5)));
			    }
			      return (List<T>) product;
			}
			
			else if(s.equals("laptops"))
			{
				while(resultSet.next())
			    {
			    	product.add(new Laptops(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getDouble(4), resultSet.getDouble(5)));
			    }
			      return (List<T>) product;
			}
			else
			{
				
					while(resultSet.next())
				    {
				    	product.add(new Watches(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3), resultSet.getDouble(4), resultSet.getDouble(5)));
				    }
				      return (List<T>) product;
				
			}
			
		}catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return null;
	}

	
	

	@Override
	public void insertItem(T e) {
		
		try {

			this.preparedStatement = this.connection.getPreparedStatement("insert into "+e.toString()+" values(?,?,?,?,?)");
			if((e.toString()).equals("television"))
			{
				this.preparedStatement.setInt(1, ((Television) e).getId());
				this.preparedStatement.setString(2, ((Television)e).getModel());
				this.preparedStatement.setString(3, ((Television)e).getPath());
				this.preparedStatement.setDouble(4, ((Television)e).getPrice());
				this.preparedStatement.setDouble(5, ((Television)e).getDiscount());
			}
			else if((e.toString()).equals("mobiles"))
			{
				this.preparedStatement.setInt(1, ((Mobiles) e).getId());
				this.preparedStatement.setString(2, ((Mobiles)e).getModel());
				this.preparedStatement.setString(3, ((Mobiles)e).getPath());
				this.preparedStatement.setDouble(4, ((Mobiles)e).getPrice());
				this.preparedStatement.setDouble(5, ((Mobiles)e).getDiscount());
			}
			else if((e.toString()).equals("laptops"))
			{
				this.preparedStatement.setInt(1, ((Laptops) e).getId());
				this.preparedStatement.setString(2, ((Laptops)e).getModel());
				this.preparedStatement.setString(3, ((Laptops)e).getPath());
				this.preparedStatement.setDouble(4, ((Laptops)e).getPrice());
				this.preparedStatement.setDouble(5, ((Laptops)e).getDiscount());
			}
			else
			{
				this.preparedStatement.setInt(1, ((Watches) e).getId());
				this.preparedStatement.setString(2, ((Watches)e).getModel());
				this.preparedStatement.setString(3, ((Watches)e).getPath());
				this.preparedStatement.setDouble(4, ((Watches)e).getPrice());
				this.preparedStatement.setDouble(5, ((Watches)e).getDiscount());
			}
			
			
			this.preparedStatement.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		
		
		
		
	}

	@Override
	public void updateItemDiscount(T e, double discount) {
		// TODO Auto-generated method stub
		
		

		try {

			this.preparedStatement = this.connection.getPreparedStatement("update "+(e.toString())+" set discount=? where id=?");
			this.preparedStatement.setDouble(1, discount);
			if((e.toString()).equals("television"))
			{
				this.preparedStatement.setInt(2,((Television) e).getId());
			}
			else if((e.toString()).equals("mobiles"))
			{
				this.preparedStatement.setInt(2,((Mobiles) e).getId());
			}
			else if((e.toString()).equals("laptops"))
			{
				this.preparedStatement.setInt(2,((Laptops) e).getId());
			}
			else
			{
				this.preparedStatement.setInt(2, ((Watches) e).getId());
			}
			this.preparedStatement.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch blocT
			e1.printStackTrace();
		}
		
		
		
	}

	@Override
	public void deleteItem(T e) {
		// TODO Auto-generated method stub
		
		try {

			this.preparedStatement = this.connection.getPreparedStatement("delete from "+e.toString()+" where id=?");
			if((e.toString()).equals("television"))
			{
				this.preparedStatement.setInt(1, ((Television) e).getId());
			}
			else if((e.toString()).equals("mobiles"))
			{
				this.preparedStatement.setInt(1, ((Mobiles) e).getId());
			}
			else if((e.toString()).equals("laptops"))
			{
				this.preparedStatement.setInt(1, ((Laptops) e).getId());
			}
			else
			{
				this.preparedStatement.setInt(1, ((Watches) e).getId());
			}
		    this.preparedStatement.executeUpdate();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
	}




	@SuppressWarnings("unchecked")
	@Override
	public T getItem(int id,String s) {
		// TODO Auto-generated method stub
ResultSet resultSet = null;
		
		T t=null;
		try {
			 this.preparedStatement=this.connection.getPreparedStatement("select * from "+s+" where id=?");
	          this.preparedStatement.setInt(1,id);
	          resultSet = this.preparedStatement.executeQuery();
	          if(s.equals("television"))
	          {
	         while(resultSet.next())
	         {
	        	t=(T)new Television(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),resultSet.getDouble(4),resultSet.getDouble(5));
		          
	         }
	          }
	          else  if(s.equals("mobiles"))
	          {
	         while(resultSet.next())
	         {
	        	t=(T)new Mobiles(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),resultSet.getDouble(4),resultSet.getDouble(5));
		          
	         }
	          }
	          else if(s.equals("laptops"))
	          {
	         while(resultSet.next())
	         {
	        	t=(T)new Laptops(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),resultSet.getDouble(4),resultSet.getDouble(5));
		          
	         }
	          }
	          else
	          {
	        	
		         while(resultSet.next())
		         {
		        	t=(T)new Watches(resultSet.getInt(1), resultSet.getString(2), resultSet.getString(3),resultSet.getDouble(4),resultSet.getDouble(5));
			          
		         }
		          
	          }
	          
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
         if(t==null)
         {
        	 System.out.println("Item not found");
        	 return null;
         }
         else
        	 return t;
	}
	
	@Override
	public void createItemTable(String s) {
		// TODO Auto-generated method stub
		
		
		try {
			String sql="create table "+s+"(id integer,model varchar(50),path varchar(50),price double,discount double)";
			this.preparedStatement=this.connection.getPreparedStatement(sql);
		    this.preparedStatement.execute();
		    System.out.println("Table "+s+" successfully created");
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

		}
		
	}


	@Override
	public void clearAll(String s) {
		// TODO Auto-generated method stub
		try {
			String sql="delete from "+s;
			this.preparedStatement=this.connection.getPreparedStatement(sql);
		    this.preparedStatement.execute();
		    System.out.println("Table "+s+" successfully cleared");
			
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();

		}
	}


	

}
