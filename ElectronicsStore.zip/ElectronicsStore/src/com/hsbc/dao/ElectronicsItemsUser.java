package com.hsbc.dao;

import java.sql.ResultSet;
import java.util.List;
import java.util.Map;

/**
 * This interface provides functions to perform CRUD operations on cart table
 * @author SANTVANA NIGAM
 *
 */

public interface ElectronicsItemsUser {
      
	       public void createCartTable();
	       
	       public boolean clearCartTable();
	       
	       public  void deleteCartItem(int id);
	       
	       public void addToCart(int id,double price);
	       
	       public void updateItemPrice(int id,double price);
	       
	       public Map<Integer,Double> getAllItems();
	       
	
}
