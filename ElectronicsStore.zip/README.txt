Task: To demonstrate basic CRUD operations.

This piece of code implements an online shopping cart.

This is based on MVC architecture.

The Items include ELectronic Items(Laptops,Watches,Mobiles,Television).

Each item  has id,model,path(where its image is stored),price and discount.

All the values are fetched from the database at runtime.

When the user has added items to the cart he can:

1) Remove items from the cart
2) Apply coupon(On click of Apply Coupon will deduct the discount from the original  price)

The actual price ,total price and discount are displayed on the  same page.

The user can then click on the checkout button to place the order.


Note :  All  the data has been fed into the database using a separate class 'StoreData'.


