package com.EveryDayGoodProducts.ViewLayer;

import java.util.ArrayList;

import com.EveryDayGoodProducts.BusinessLogicLayer.AllProducts;
import com.EveryDayGoodProducts.BusinessLogicLayer.Apparel;
import com.EveryDayGoodProducts.BusinessLogicLayer.Electronics;
import com.EveryDayGoodProducts.BusinessLogicLayer.FoodItems;
import com.EveryDayGoodProducts.DataAccessLayer.PrintApparelItems;
import com.EveryDayGoodProducts.DataAccessLayer.PrintElectronicItems;
import com.EveryDayGoodProducts.DataAccessLayer.PrintFoodItems;

/**
 * 
 * @author OM ASHISH MISHRA
 *
 */

/* Main - This is present to handle payments and calling other fucntions.*/
public class Main {
	
	/* Default Constructor */
	public Main() {
		// TODO Auto-generated constructor stub
	}
	
	public static void main(String[] args) {
		

		Apparel apparel1 = new Apparel(1,"CottonShirt",123,3,"Cotton",2);
		FoodItems food1 = new FoodItems(1,"ChocolateChips",125,12,"12-09-2018","12-09-2019","Veg",2);
		Electronics electron1 = new Electronics(1,"TV Remote",240,6, 1);
		
		PrintApparelItems p = new PrintApparelItems();
		p.printRecords(apparel1);
		PrintElectronicItems e = new PrintElectronicItems();
		e.printRecords(electron1);
		PrintFoodItems f = new PrintFoodItems();
		f.printRecords(food1);
		
		
		AllProducts items[] = {apparel1,food1,electron1};
		
		Checkout c = new Checkout();
		c.addItems(items);
		
		System.out.println(c);
		c.clearCart();
		System.out.println(c);
		
	}
	

}
