# Om_Ashish_Mishra_Java_Practical
This is for the 24/09/2020 assignment.

This is about OOPS Concept and proper coding practing Techniques.
