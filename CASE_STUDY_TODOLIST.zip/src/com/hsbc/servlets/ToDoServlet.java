package com.hsbc.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.hsbc.dao.CRUD;

/**
 * Servlet implementation class ToDoServlet
 */
@WebServlet("/ToDoServlet")
public class ToDoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ToDoServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		this.doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		String taskname=request.getParameter("taskname");
		String taskdec=request.getParameter("taskdec");
		String taskdate=request.getParameter("taskdate");
		//String username=request.getParameter("name");
		
		HttpSession session=request.getSession(false);//only open existing session
		String name=(String)session.getAttribute("sessionname"); 
		if(session!=null) {
			out.println("welcome "+name);
			//out.println(session.getId());
			session.invalidate();// if you dont do this then after refresh also it will show same session id
		}
		CRUD c=new CRUD();
		try {
			String a=c.inserttask(taskname, taskdec, taskdate, name);
			//out.println(a);
			RequestDispatcher d=request.getRequestDispatcher("ToDo.jsp");
			request.setAttribute("answer", a);
			d.forward(request, response);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//out.println(c.viewList(name));
		
		
		
		
	}

}
