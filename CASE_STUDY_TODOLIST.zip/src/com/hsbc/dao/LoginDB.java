package com.hsbc.dao;

import java.awt.List;
import java.beans.Statement;
import java.sql.ResultSet;


import java.sql.SQLException;
import java.util.ArrayList;

import com.hsbc.connection.DBConnection;

public class LoginDB  {
	DBConnection db=new DBConnection();
	public String checkUser(String username,String password) {
		try {
			
			 java.sql.Statement st=db.getStatement();
			
			 
			 //pst.setString(1,"username");
			 ResultSet rs=null;
			 String sql="select * from users";
			 
			  rs =  st.executeQuery(sql);
			 String orPass="";
			 /*while(rs!=null) {
				 orPass=rs.getString("Password");
				 if(orPass.equals(password)) {
					 return "You are a verified user. welcome!";
					 
				 }
				 else {
					 return "Not a verified user";
					 
				 }
			
			 }*/
			 while(rs.next()) {
				 if((username.equals(rs.getString(1))) && (password.equals(rs.getString(2)))){
					 return "Verified";
				 }
				 else {
					 return "Please verify";
					 
				 }

			 }
		
				 
			 
		}catch(SQLException e) {
			System.out.println(e);
		}
		return null;
	}
	public ArrayList getUsers() {
		ArrayList l=new ArrayList();
		try {
			java.sql.Statement st=db.getStatement();
			ResultSet rs=st.executeQuery("Select *from users");
			while(rs.next()) {
				l.add(rs.getString(1)+""+rs.getString(2));
				
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		return l;
		
	}
	
	

}
