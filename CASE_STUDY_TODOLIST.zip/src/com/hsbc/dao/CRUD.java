package com.hsbc.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.hsbc.connection.DBConnection;

public class CRUD<T> {
	DBConnection db=new DBConnection();
	public String inserttask(String taskname,String taskdescp,String date,String username) throws SQLException {
		java.sql.Statement st=db.getStatement();
		st.execute("insert into taskdetails values('"+taskname+"','"+taskdescp+"','"+date+"','"+username+"')");
		return "Task is added";
		
		
	}
	
	@SuppressWarnings("unchecked")
	public ArrayList<T> viewList(String uname) {
		ArrayList<T> l=new ArrayList<T>();
		try {
			java.sql.Statement st=db.getStatement();
			ResultSet rs=st.executeQuery("Select * from taskdetails ");
			while(rs.next()) {
				l.add((T) (rs.getString(1)+" "+rs.getString(2)+"    " +rs.getString(3)+"    "+rs.getString(4)));
				
			}
		}catch(Exception e) {
			System.out.println(e);
		}
		return l;
		
	}
	
	public String updateTask(String tname,String tdesc) throws SQLException {
		
			//PreparedStatement pstmt = conn.prepareStatement(sqlUpdate);
			PreparedStatement pst = db.getPreparedStatement("update taskdetails"+" set taskdescp=?"+ "  where taskname=?");
		String taskname = tname;
          String taskdescp = tdesc;

pst.setString(1, taskname);
pst.setString(2, taskdescp);

		int row=pst.executeUpdate();
		return "Description added";
		
		
			
			
		
		
	}

}
