package com.hsbc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.hsbc.connection.DBConnection;

public class RegisterDB {
	DBConnection db=new DBConnection();
	public String addUser(String username,String password) {
		try {
			java.sql.Statement st=db.getStatement();
			
			
			st.execute("insert into users values('"+username+"','"+password+"')");
			 return "User registered successfully";
			 
			
		}catch(SQLException e) {
			System.out.println(e);
		}
		return null;
	}

}
