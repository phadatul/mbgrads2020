package com.hsbc.learn.serveletCollboration;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hsbc.learn.Servelets.LoginDB;
import com.sun.corba.se.spi.protocol.RequestDispatcherDefault;

/**
 * Servlet implementation class collab
 */
@WebServlet("/collab")
public class collab extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public collab() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		collab c = new collab();
		c.doPost(request,response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter responsewriter = response.getWriter();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		responsewriter.println(".............IN COLLAB SERVELET..........");
		responsewriter.println(".............USERNAME.........."+ username);
		responsewriter.println(".............PASSWORD.........."+ password);
		//response.sendRedirect("Profile");
		RequestDispatcher d= request.getRequestDispatcher("Profile");
		d.forward(request,response);
		//d.include(request, response);
		
	}

}
