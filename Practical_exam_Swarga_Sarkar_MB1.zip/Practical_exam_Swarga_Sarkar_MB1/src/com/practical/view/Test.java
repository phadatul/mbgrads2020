package com.practical.view;

import com.practical.entity.FoodItems;

/**
 * 
 * @author Swarga Sarkar
 * @purpose This class contains the main functionby
 *
 */
public class Test {

	public static void main(String[] args) {
		FoodItems fi1= new FoodItems(101,"Milk", 100, 40, "21/12/2019", "21/12/2020", "yes");
		FoodItems fi2= new FoodItems(102,"Meat", 100, 70, "21/12/2019", "21/12/2020", "yes");
		FoodItems fi3= new FoodItems(103,"Sweets", 100,60, "21/12/2019", "21/12/2020", "yes");
		FoodItems fi4= new FoodItems(104,"Rice", 100, 40, "21/12/2019", "21/12/2020", "yes");
		
	}
}
